# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

data = pd.read_csv("daily_weather_data.csv")
data.head()
orszagok=[]
data.head()

data.head()
print(len(data))
data=data.dropna()
print(len(data))
data.drop(columns=["pres","wdir"])
print(len(data))

for i in data["country"]:
  if i not in orszagok:
    orszagok.append(i)
    
print(orszagok)

orszagsor= dict()
szamol=0
for i in range(len(orszagok)):
  orszagsor.update({orszagok[szamol]: []})
  szamol+=1
print(orszagsor)


data.head()
data[data["country"] == "ország"]

for i in orszagsor.keys():
  orszag_table = data[data["country"]== i]
  orszagsor[i] = orszag_table[["date","tavg",'wspd']]
print(orszagsor)



kulcs = input("orszag ")
try:
  print(orszagsor[kulcs])
except ValueError:
  print("ilyen pont nincs")
ize= orszagsor[kulcs]

datum = ize['date']
tavg = ize['tavg']

plt.plot(datum, tavg, linewidth=0.5, color='black')
plt.xlabel('datum')
plt.ylabel('atlag homerseklet')
plt.show()

tavg = orszagsor[kulcs]['tavg']

X_train, X_test, y_train, y_test = train_test_split(np.arange(len(tavg)).reshape(-1, 1), tavg, test_size=0.2, random_state=0)

reg = LinearRegression().fit(X_train, y_train)

future_tavg = reg.predict(np.array([[len(tavg) + i] for i in range(1, 365)]))
print(X_train)

"""a"""

plt.plot(future_tavg, linewidth=0.5, color='green')
plt.xlabel('datum')
plt.scatter(X, y_train)
plt.ylabel('atlag homerseklet')
plt.show()

X=[]
for i in X_train:
  X.append(i[0])
mymodel = np.poly1d(np.polyfit(X, y_train, 16))
myline = np.linspace(1, 1750, 100)
plt.scatter(X, y_train)
plt.plot(myline, mymodel(myline), color='red')
plt.show()